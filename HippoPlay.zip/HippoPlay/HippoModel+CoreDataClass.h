//
//  HippoModel+CoreDataClass.h
//  HippoPlay
//
//  Created by xlkd 24 on 2019/4/13.
//  Copyright © 2019 xlkd 24. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface HippoModel : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "HippoModel+CoreDataProperties.h"
