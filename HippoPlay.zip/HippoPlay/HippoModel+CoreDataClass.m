//
//  HippoModel+CoreDataClass.m
//  HippoPlay
//
//  Created by xlkd 24 on 2019/4/13.
//  Copyright © 2019 xlkd 24. All rights reserved.
//
//

#import "HippoModel+CoreDataClass.h"

@implementation HippoModel

@end
