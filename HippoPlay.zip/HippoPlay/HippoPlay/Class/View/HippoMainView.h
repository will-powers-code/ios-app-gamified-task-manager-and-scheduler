//
//  HippoMainView.h
//  HippoPlay
//
//  Created by xlkd 24 on 2019/4/12.
//  Copyright © 2019 xlkd 24. All rights reserved.
//

#import <UIKit/UIKit.h>



NS_ASSUME_NONNULL_BEGIN

@interface HippoMainView : UIView

/**
 初始化视图

 @param enterActionBlock 回调
 @return self
 */
- (instancetype)initWithEnterAction:(void(^)(void))enterActionBlock;

/**
 修改食物 -- 完成了任务计划开始添加  -- 0.1代表一个  1.0表示满了

 @param food 需要添加的食物个数
 */
- (void)configWithChangeFood:(float)food;

/**
 修改心情  -- 玩了游戏开始修改心情

 @param mood 需要添加的心情个数  -- 0.1代表一个 1.0表示满了
 */
- (void)configWithChangeMood:(float)mood;

@end

NS_ASSUME_NONNULL_END
