//
//  HippoMainView.m
//  HippoPlay
//
//  Created by xlkd 24 on 2019/4/12.
//  Copyright © 2019 xlkd 24. All rights reserved.
//



#import "HippoMainView.h"
#import "Masonry.h"
#import "HippoBodyStatusView.h"
#import "HippoManager.h"
#import "YYWebImage.h"

@interface HippoMainView ()

@property(nonatomic,strong)UIImageView *hippoBackImageView;
@property (nonatomic,strong)HippoBodyStatusView *hippoBodyView;
@property (nonatomic,copy) void (^enterActionBlock)(void);
@property (nonatomic,assign)SummerOrderStatus type;
@property (nonatomic,strong)YYAnimatedImageView *titleImageView;

@end
@implementation HippoMainView


- (instancetype)initWithEnterAction:(void(^)(void))enterActionBlock {
    self = [super init];
    if (self) {
        [self summer_setupViews];
        [self summer_bindViewModel];
        [self configDataNormalWithUI];
        [self configCreateDataTool];
        self.enterActionBlock = enterActionBlock;
    }
    return self;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self summer_setupViews];
        [self summer_bindViewModel];
        
        [self configCreateDataTool];
    }
    return self;
}
- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self summer_setupViews];
        [self summer_bindViewModel];
    }
    return self;
}
- (void)updateConstraints {
    [super updateConstraints];
}
- (void)summer_bindViewModel {
    
}

- (void)summer_setupViews {
    
    self.backgroundColor = [UIColor whiteColor];
    __weak typeof(self) weakSelf = self;
//    [self addSubview:self.hippoBackImageView];
//
//    [self.hippoBackImageView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.centerY.equalTo(weakSelf.mas_centerY);
//        make.centerX.equalTo(weakSelf.mas_centerX);
//        make.height.mas_equalTo(STSizeWithWidth(240.0));
//        make.width.mas_equalTo(STSizeWithWidth(240.0));
//    }];
    [self addSubview:self.titleImageView];
    
    [self.titleImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(weakSelf.mas_centerY);
        make.centerX.equalTo(weakSelf.mas_centerX);
        make.height.mas_equalTo(STSizeWithWidth(240.0));
        make.width.mas_equalTo(STSizeWithWidth(240.0));
    }];
    
    UITapGestureRecognizer *tapSingle = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapSingleDid:)];
    tapSingle.numberOfTapsRequired = 1;
    tapSingle.numberOfTouchesRequired = 1;
    
    //双击监听
    UITapGestureRecognizer *tapHoippoDouble = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapDoubleDid:)];
    tapHoippoDouble.numberOfTapsRequired = 2;
    tapHoippoDouble.numberOfTouchesRequired = 1;
    //声明点击事件需要双击事件检测失败后才会执行
    [tapSingle requireGestureRecognizerToFail:tapHoippoDouble];
    
//    [self.hippoBackImageView addGestureRecognizer:tapSingle];
//    [self.hippoBackImageView addGestureRecognizer:tapHoippoDouble];
    [self.titleImageView addGestureRecognizer:tapSingle];
    [self.titleImageView addGestureRecognizer:tapHoippoDouble];
    
}

- (void)tapSingleDid:(UITapGestureRecognizer *)tapGesture {
    
    CGPoint ponit = [tapGesture locationInView:self.titleImageView];
    if ([tapGesture.view isEqual:self.titleImageView]) {
        switch (self.type) {
            case ACTIVE:
                //单机  -- 根据坐标点来切换图片
                [self configSingeTapWithPoint:ponit];
                break;
            case GETDOWN:
                // 一分钟不懂 河马会趴下  双击  唤醒河马
                self.type = ACTIVE;
                [self configDataWithUI:self.type];
                break;
            case EGG:
                //变蛋  -- 单机失效
                [self configSingeTapWithPoint:ponit];
                break;
                
            default:
                break;
        }
    }
}

- (void)tapDoubleDid:(UITapGestureRecognizer *)tapGesture {
    
    if ([tapGesture.view isEqual:self.titleImageView]) {
        switch (self.type) {
            case ACTIVE:
                //站起来了  -- 双击出现菜单键
                [self configPushMnue];
                break;
            case GETDOWN:
                // 一分钟不懂 河马会趴下  双击  唤醒河马
                self.type = ACTIVE;
                [self configDataWithUI:self.type];
                break;
            case EGG:
                //变蛋  -- 双击出现菜单键
                [self configPushMnue];
                break;
            default:
                break;
        }
    }
}

/**
 根据点击的位置来显示对应的gif图

 @param point 点击的点
 */
- (void)configSingeTapWithPoint:(CGPoint)point {
    NSLog(@"%lf---%lf",point.x,point.y);
    NSURL *path = [[NSBundle mainBundle]URLForResource:@"无网络插图" withExtension:@"gif"];
    self.titleImageView.yy_imageURL = path;
    __weak __typeof(self) weakSelf = self;
    [[HippoManager shareInstance] configDataWithGifWoth:3 timerSuccess:^{
        //
        [weakSelf configDataWithUI:weakSelf.type];
    }];
    
    
}
- (void)configDataNormalWithUI {
    SummerOrderStatus type =  [[HippoManager shareInstance] configDataNormalWithUI];
    [self configDataWithUI:type];
}
#pragma mark - 基本推出方法
- (void)configPushMnue {
    if ([self.subviews containsObject:self.hippoBodyView]) {
        //已经出现了  -- 移除
        [self configChangeUiNormalWithCenterImage];
        [self.hippoBodyView removeFromSuperview];
    } else {
        //没有出现   -- 显示
        [UIView animateWithDuration:3.0 animations:^{
            [self configChangeUiSelectWithCenterImage];
            [self addSubview:self.hippoBodyView];
            __weak typeof(self) weakSelf = self;
            [self.hippoBodyView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.right.equalTo(weakSelf.mas_right);
                make.centerY.equalTo(weakSelf.mas_centerY);
                make.height.mas_equalTo(STSizeWithWidth(400.0));
                make.width.mas_equalTo(STSizeWithWidth(260.0));
            }];
        }];
    }
}

- (void)configChangeUiSelectWithCenterImage {
    __weak typeof(self) weakSelf = self;
    [self.titleImageView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(weakSelf.mas_centerY);
        make.centerX.equalTo(weakSelf.mas_centerX).offset(-STSizeWithWidth(130.0));
        make.height.mas_equalTo(STSizeWithWidth(240.0));
        make.width.mas_equalTo(STSizeWithWidth(240.0));
    }];
    [self.titleImageView layoutIfNeeded];
}
- (void)configChangeUiNormalWithCenterImage {
    __weak typeof(self) weakSelf = self;
    [self.titleImageView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(weakSelf.mas_centerY);
        make.centerX.equalTo(weakSelf.mas_centerX);
        make.height.mas_equalTo(STSizeWithWidth(240.0));
        make.width.mas_equalTo(STSizeWithWidth(240.0));
    }];
    [self.titleImageView layoutIfNeeded];
}

/**
 食物修改

 @param food 更改值得大小
 */
- (void)configWithChangeFood:(float)food {
    __weak __typeof(self) weakSelf = self;
    [[HippoManager shareInstance] configDataWithAddFood:food foodSuccess:^(float mood, float food, float exp) {
        if ([weakSelf.subviews containsObject:weakSelf.hippoBodyView]) {
            [weakSelf.hippoBodyView configChangeUIWithData:mood andExpNumber:exp andFoodNumber:food];
        }
    }];
}

/**
 修改心情

 @param mood 心情值得大小
 */
- (void)configWithChangeMood:(float)mood {
    __weak __typeof(self) weakSelf = self;
    [[HippoManager shareInstance] configDataWithAddMood:mood moodSuccess:^(float mood, float food, float exp) {
        if ([weakSelf.subviews containsObject:weakSelf.hippoBodyView]) {
            [weakSelf.hippoBodyView configChangeUIWithData:mood andExpNumber:exp andFoodNumber:food];
        }
        
    }];
    [self configDataNormalWithUI];
}
- (void)configDataWithUI:(SummerOrderStatus)type {
    self.type = type;
    switch (self.type) {
        case ACTIVE:
            self.titleImageView.image = [UIImage imageNamed:@"masterLayer_tmp.0001"];
            break;
        case GETDOWN:
            self.titleImageView.image = [UIImage imageNamed:@"masterLayer_tmp.0001"];
            break;
        case EGG:
            self.titleImageView.image = [UIImage imageNamed:@"masterLayer_tmp.0001"];
            break;
        default:
            break;
    }
}
- (void)configCreateDataTool {
//    [[HippoManager shareInstance] createSqlite];
    __weak __typeof(self) weakSelf = self;
    [[HippoManager shareInstance] configDataWithGcdTimerSuccess:^(float mood, float food, float exp) {
        if ([weakSelf.subviews containsObject:weakSelf.hippoBodyView]) {
            [weakSelf.hippoBodyView configChangeUIWithData:mood andExpNumber:exp andFoodNumber:food];
        }
    }];
}
- (void)configBodyStatusAction:(NSInteger)tag {
    switch (tag) {
        case 10:
        {
            if (self.enterActionBlock != nil) {
                self.enterActionBlock();
            }
            break;
        }
        case 20:
        {
            NSLog(@"清理便便");
            bool isSelect = YES;
            if (isSelect) {
                isSelect = NO;
                __weak __typeof(self) weakSelf = self;
                [[HippoManager shareInstance] configDataWithClearShitSuccess:^(float mood, float food, float exp) {
                    if ([weakSelf.subviews containsObject:weakSelf.hippoBodyView]) {
                        [weakSelf.hippoBodyView configChangeUIWithData:mood andExpNumber:exp andFoodNumber:food];
                    }
                }];
//                HippoModel *model = [[HippoToolManager shareInstance] readData];
//                float moodNumber = model.mood; //当前的心情
//                float foodNumber = model.food; //当前的食物总量
//                float expNumber = model.exp; //当前的饱程度
//                int16_t shitNumber = model.shitNumber; //当前的便便量
//                NSString *endDownStatus = model.downStatus; //当前河马状态
//                NSString *endExpNumberTime = model.changeExpTime; //最后饥饿度
//                NSString *endMoodNumberTime = model.changeMoodTime; //最后河马拉屎时间
//                NSString *endActionNumberTime = model.actionTime; //最后趴下时间
//                NSString *endShitTime = model.changeShitTime; //屎太多影响心情的时间
//                shitNumber = 0;
//                endShitTime = [[HippoToolManager shareInstance] getCurrentTiem];
//                endMoodNumberTime = [[HippoToolManager shareInstance] getCurrentTiem];
//                [[HippoToolManager shareInstance] updateDataId:@"1" actionTime:endActionNumberTime changeExpTime:endExpNumberTime changeMoodTime:endMoodNumberTime food:foodNumber exp:expNumber mood:moodNumber shitNumber:shitNumber downStatus:endDownStatus changeShitTime:endShitTime];
                
                isSelect = YES;
            }
            break;
        }
        case 30:
            NSLog(@"心情");
            break;
        case 40:
            NSLog(@"饱程度");
            break;
        case 50:
        {
            NSLog(@"喂食");
            bool isSelect = YES;
            if (isSelect) {
                isSelect = NO;
                __weak __typeof(self) weakSelf = self;
                [[HippoManager shareInstance] configDataWithEatSuccess:^(float mood, float food, float exp) {
                    if ([weakSelf.subviews containsObject:weakSelf.hippoBodyView]) {
                        [weakSelf.hippoBodyView configChangeUIWithData:mood andExpNumber:exp andFoodNumber:food];
                    }
                }];
//                HippoModel *model = [[HippoToolManager shareInstance] readData];
//                float moodNumber = model.mood; //当前的心情
//                float foodNumber = model.food; //当前的食物总量
//                float expNumber = model.exp; //当前的饱程度
//                int16_t shitNumber = model.shitNumber; //当前的便便量
//                NSString *endDownStatus = model.downStatus; //当前河马状态
//                NSString *endExpNumberTime = model.changeExpTime; //最后饥饿度
//                NSString *endMoodNumberTime = model.changeMoodTime; //最后河马拉屎时间
//                NSString *endActionNumberTime = model.actionTime; //最后趴下时间
//                NSString *endShitTime = model.changeShitTime; //屎太多影响心情的时间
//                if (foodNumber <= 0 || expNumber > 0.95) {
//                    isSelect = YES;
//                    return;
//                }
//                foodNumber = foodNumber - 0.1;
//                expNumber = expNumber + 0.1;
//                [[HippoToolManager shareInstance] updateDataId:@"1" actionTime:endActionNumberTime changeExpTime:endExpNumberTime changeMoodTime:endMoodNumberTime food:foodNumber exp:expNumber mood:moodNumber shitNumber:shitNumber downStatus:endDownStatus changeShitTime:endShitTime];
//                if ([self.subviews containsObject:self.hippoBodyView]) {
//                    [self.hippoBodyView configChangeUIWithData:moodNumber andExpNumber:expNumber andFoodNumber:foodNumber];
//                }
                isSelect = YES;
            }
            break;
        }
        default:
            break;
    }
}

#pragma mark - get
- (UIImageView *)hippoBackImageView {
    if (!_hippoBackImageView) {
        _hippoBackImageView = [[UIImageView alloc]init];
        [_hippoBackImageView setUserInteractionEnabled:YES];
    }
    return _hippoBackImageView;
}
- (HippoBodyStatusView *)hippoBodyView {
    if (!_hippoBodyView) {
        __weak typeof(self) weakSelf = self;
        _hippoBodyView = [[HippoBodyStatusView alloc]initWithMood:1.0 andExp:1.0 andFood:1.0 enterAction:^(NSInteger tag) {
            [weakSelf configBodyStatusAction:tag];
        }];
    }
    return _hippoBodyView;
}

- (YYAnimatedImageView *)titleImageView {
    if (!_titleImageView) {
        _titleImageView = [[YYAnimatedImageView alloc]init];
        [_titleImageView setUserInteractionEnabled:YES];
    }
    return _titleImageView;
}
@end
