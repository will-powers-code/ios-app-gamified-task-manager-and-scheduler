//
//  HippoViewController.m
//  HippoPlay
//
//  Created by xlkd 24 on 2019/4/12.
//  Copyright © 2019 xlkd 24. All rights reserved.
//

#import "HippoViewController.h"
#import "HippoMainView.h"
//#import "HippoBodyStatusView.h"
//#import "HippoModel+CoreDataProperties.h"
//#import "HippoManager.h"

@interface HippoViewController ()
@property (nonatomic,strong)HippoMainView *hippoMianView;
//@property (nonatomic,strong)HippoBodyStatusView *hippoBodyView;
//@property (nonatomic, strong) GCDTimer  *gcdTimer;
@end

@implementation HippoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"河马日历";
    [self configUI];
//    HippoModel *model = [[HippoToolManager shareInstance] readData];
//    if (model == nil) {
//        //不存在了
//        [[HippoToolManager shareInstance] createSqlite];
//        [[HippoToolManager shareInstance] insertDataId:@"1" actionTime:[[HippoToolManager shareInstance] getCurrentTiem] changeExpTime:[[HippoToolManager shareInstance] getCurrentTiem] changeMoodTime:[[HippoToolManager shareInstance] getCurrentTiem] food:1.0 exp:1.0 mood:1.0 shitNumber:1.0 downStatus:@"0" changeShitTime:[[HippoToolManager shareInstance] getCurrentTiem]];
//
//    }
//    [[HippoManager shareInstance] createSqlite];
//    __weak __typeof(self) weakSelf = self;
//    [[HippoManager shareInstance] configDataWithGcdTimerSuccess:^(float mood, float food, float exp) {
//        [weakSelf.hippoBodyView configChangeUIWithData:mood andExpNumber:exp andFoodNumber:food];
//    }];
//    [self configDataWithGcdTimer];
}

#pragma mark - GCDTimer
//- (void)configDataWithGcdTimer {
//    __weak __typeof(self) weakSelf = self;
//    self.gcdTimer = [[GCDTimer alloc] initInQueue:[GCDQueue mainQueue]];
//    [self.gcdTimer event:^{
//        //
//        [weakSelf configDataWithModel:[[HippoToolManager shareInstance] getCurrentTiem]];
//
//    } timeInterval:NSEC_PER_SEC * 1.0];
//
//    [self.gcdTimer start];
//}


- (void)configUI {
    
    self.edgesForExtendedLayout = UIRectEdgeNone;
    [self.navigationController.navigationBar setTranslucent:NO];
    
    [self.view addSubview:self.hippoMianView];
    __weak typeof(self) weakSelf = self;
    [self.hippoMianView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(weakSelf.view.mas_right).offset(-STSizeWithWidth(30.0));
        make.bottom.equalTo(weakSelf.view.mas_bottom);
        make.height.mas_equalTo(STSizeWithWidth(500.0));
        make.width.mas_equalTo(STSizeWithWidth(500.0));
        
    }];
}
- (void)configHippoPlayGame {
    NSLog(@"玩游戏");
}
//#pragma mark - 基本推出方法
//- (void)configPushMnue {
//    if ([self.view.subviews containsObject:self.hippoBodyView]) {
//        //已经出现了  -- 移除
//        [self.hippoBodyView removeFromSuperview];
//    } else {
//        //没有出现   -- 显示
//        [self.view addSubview:self.hippoBodyView];
//        __weak typeof(self) weakSelf = self;
//        [self.hippoBodyView mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.left.equalTo(weakSelf.view.mas_left);
//            make.top.equalTo(weakSelf.view.mas_top).offset(STSizeWithWidth(60.0));
//            make.height.mas_equalTo(STSizeWithWidth(440.0));
//            make.width.mas_equalTo(STSizeWithWidth(300.0));
//        }];
//    }
//
//
//}

//- (void)configDataWithModel:(NSString *)time {
//    HippoModel *model = [[HippoToolManager shareInstance] readData];
////    NSLog(@"summer--mood--%lf",model.mood);
////    NSLog(@"summer--%hd",model.shitNumber);
////    NSLog(@"summer--%@",model.downStatus);
////    NSLog(@"summer--%@",model.changeShitTime);
////    NSLog(@"summer--changeMoodTime--%@",model.changeMoodTime);
////    NSLog(@"summer--%@",model.changeExpTime);
////    NSLog(@"summer--%@",model.actionTime);
////    NSLog(@"summer--time--%@",time);
//    float moodNumber = model.mood; //当前的心情
//    float foodNumber = model.food; //当前的食物总量
//    float expNumber = model.exp; //当前的饱程度
//    int16_t shitNumber = model.shitNumber; //当前的便便量
//    long int shitNumberTime = [time integerValue] - [model.changeShitTime integerValue]; //屎太多  -- 开始影响心情
//    long int moodNumberTime = [time integerValue] - [model.changeMoodTime integerValue]; //河马拉屎的间隔
//    long int actionNumberTime = [time integerValue] - [model.actionTime integerValue]; //河马是否趴下 -- 差值
//    long int expNumberTime = [time integerValue] - [model.changeExpTime integerValue]; //饥饿度 -- 差值
//
//    NSString *endDownStatus = model.downStatus; //当前河马状态
//    NSString *endExpNumberTime = model.changeExpTime; //最后饥饿度
//    NSString *endMoodNumberTime = model.changeMoodTime; //最后河马拉屎时间
//    NSString *endActionNumberTime = model.actionTime; //最后趴下时间
//    NSString *endShitTime = model.changeShitTime; //屎太多影响心情的时间
//
//    //饥饿度
//    if (expNumber == 0.0) {
//        //已经没有的消耗了  -- 保存当前时间为饥饿度时间
//        endExpNumberTime = time;
//    } else {
//        int extInt = (int)expNumberTime;
//        int number = extInt / HippoExpTime;
//        if (number > 0) {
//            //开始消耗饥饿度
//            float expChangeNumber = 0.1 * (float)number;
//            if (expNumber > expChangeNumber) {
//                //饥饿度 为相减
//                expNumber = expNumber - expChangeNumber;
//            } else {
//                //饥饿度减为0
//                expNumber = 0;
//            }
//            endExpNumberTime = time;
//        }
//    }
//    //心情
//    if (moodNumber == 0.0) {
//        //心情最差 -- 屎最多
//        endMoodNumberTime = time;
//        endShitTime = time;
//    } else {
//        if (shitNumber > HippoShitNumer) {
//            //开始影响心情
//            int number = (int)shitNumberTime / HippoMoodTime;
//            if (number > 0) {
//                //开始消耗心情
//                float moodChangeNumber = 0.1 * (float)number;
//                if (moodNumber > moodChangeNumber) {
//                    //心情 为相减
//                    moodNumber = moodNumber - moodChangeNumber;
//                } else {
//                    //心情为0
//                    moodNumber = 0;
//                }
//                endShitTime = time;
//            }
//        }
//        int number = (int)moodNumberTime / HippoShitTime;
//        if (number > 0) {
//            //开始拉屎
//            int entNumber = shitNumber + number;
//            if (entNumber == HippoShitNumer + 1) {
//                shitNumber = entNumber;
//                endMoodNumberTime = time;
//                endShitTime = time;
//            } else if (entNumber < HippoShitNumer + 1) {
//                shitNumber = entNumber;
//                endMoodNumberTime = time;
//            } else {
//                if (shitNumber <= HippoShitNumer) {
//                    //原来的不影响 -- 心情
//                    float endMoodNumber = [self configCurrenShit:shitNumber shitNewNumber:number];
//                    moodNumber = moodNumber - endMoodNumber;
//                    if (moodNumber < 0.0) {
//                        moodNumber = 0.0;
//                    }
//                    endShitTime = time;
//                }
//                shitNumber = entNumber;
//                endMoodNumberTime = time;
//            }
//        }
//    }
//    //河马趴下
//    int number = (int)actionNumberTime / HippoDownTime;
//    if (number > 0 ) {
//        endActionNumberTime = time;
//        endDownStatus = @"1";
//    }
////    if (moodNumber != model.mood || expNumber != model.exp || foodNumber != model.food || endActionNumberTime == time || endExpNumberTime == time || endMoodNumberTime == time || shitNumber !=  model.shitNumber || endDownStatus != model.downStatus || endShitTime == time) {
////        [[HippoToolManager shareInstance] updateDataId:@"1" actionTime:endActionNumberTime changeExpTime:endExpNumberTime changeMoodTime:endMoodNumberTime food:foodNumber exp:expNumber mood:moodNumber shitNumber:shitNumber downStatus:endDownStatus changeShitTime:endShitTime];
////    }
////
////    if (moodNumber != model.mood || expNumber != model.exp || foodNumber != model.food) {
////        [self.hippoBodyView configChangeUIWithData:moodNumber andExpNumber:expNumber andFoodNumber:foodNumber];
////    }
//    [[HippoToolManager shareInstance] updateDataId:@"1" actionTime:endActionNumberTime changeExpTime:endExpNumberTime changeMoodTime:endMoodNumberTime food:foodNumber exp:expNumber mood:moodNumber shitNumber:shitNumber downStatus:endDownStatus changeShitTime:endShitTime];
//    [self.hippoBodyView configChangeUIWithData:moodNumber andExpNumber:expNumber andFoodNumber:foodNumber];
//
//
//}
//
///**
// 计算影响心情数量
//
// @param shitNumber 原来就有的屎量
// @param shitNewNumber 新产生的
// @return 影响的心情
// */
//- (float)configCurrenShit:(int)shitNumber shitNewNumber:(int)shitNewNumber {
//
//    int chatShitNumber = shitNumber + shitNewNumber - HippoShitNumer - 1;
//    int changeNumber = HippoShitTime * chatShitNumber / HippoMoodTime;
//    return 0.1 * changeNumber;
//}
#pragma mark - get
- (HippoMainView *)hippoMianView {
    if (!_hippoMianView) {
        __weak typeof(self) weakSelf = self;
        _hippoMianView = [[HippoMainView alloc]initWithEnterAction:^{
            [weakSelf configHippoPlayGame];
        }];
    }
    return _hippoMianView;
}

//- (HippoBodyStatusView *)hippoBodyView {
//    if (!_hippoBodyView) {
//        __weak typeof(self) weakSelf = self;
//        _hippoBodyView = [[HippoBodyStatusView alloc]initWithMood:1.0 andExp:1.0 andFood:1.0 enterAction:^(NSInteger tag) {
//            [weakSelf configBodyStatusAction:tag];
//        }];
//    }
//    return _hippoBodyView;
//}
@end
