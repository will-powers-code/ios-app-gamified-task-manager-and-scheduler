//
//  HippoMainVM.m
//  HippoPlay
//
//  Created by xlkd 24 on 2019/4/12.
//  Copyright © 2019 xlkd 24. All rights reserved.
//

#import "HippoMainVM.h"

@interface HippoMainVM ()

@end

@implementation HippoMainVM

@end
