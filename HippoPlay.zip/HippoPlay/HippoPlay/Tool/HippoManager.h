//
//  HippoManager.h
//  HippoPlay
//
//  Created by xlkd 24 on 2019/4/16.
//  Copyright © 2019 xlkd 24. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HippoModel+CoreDataProperties.h"

typedef enum : NSUInteger {
    GETDOWN = 1,//趴下
    ACTIVE,//活跃
    EGG,//蛋
} SummerOrderStatus;

NS_ASSUME_NONNULL_BEGIN

@interface HippoManager : NSObject
+ (instancetype)shareInstance;

//判断数据库是否存在 不存在就开始创建
- (void)createSqlite;
/**
 初始化河马状态
 
 @return 河马状态
 */
- (SummerOrderStatus)configDataNormalWithUI;
/**
 计时开始
 
 @param success 回调
 */
- (void)configDataWithGcdTimerSuccess:(void (^)(float mood,float food,float exp))success;
/**
 清理便便事件
 
 @param clearShitSuccess 返回数据刷新页面
 */
- (void)configDataWithClearShitSuccess:(void (^)(float mood,float food,float exp))clearShitSuccess;
/**
 喂食
 
 @param eatSuccess 回调
 */
- (void)configDataWithEatSuccess:(void (^)(float mood,float food,float exp))eatSuccess;

/**
 添加食物
 
 @param food 添加的食物
 @param foodSuccess 成功得回调
 */
- (void)configDataWithAddFood:(CGFloat)food foodSuccess:(void (^)(float mood,float food,float exp))foodSuccess;

/**
 添加心情
 
 @param mood 添加的心情
 @param moodSuccess 成功回调
 */
- (void)configDataWithAddMood:(CGFloat)mood moodSuccess:(void (^)(float mood,float food,float exp))moodSuccess;


- (void)configDataWithGifWoth:(NSInteger)time timerSuccess:(void (^)(void))gifSuccess;

@end

NS_ASSUME_NONNULL_END
