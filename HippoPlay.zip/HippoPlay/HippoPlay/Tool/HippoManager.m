//
//  HippoManager.m
//  HippoPlay
//
//  Created by xlkd 24 on 2019/4/16.
//  Copyright © 2019 xlkd 24. All rights reserved.
//

#import "HippoManager.h"

@interface HippoManager ()
@property (nonatomic, strong) GCDTimer  *gcdTimer;
@property (nonatomic,copy)void (^chooseBtnViewBlock)(float mood,float food,float exp);
@property (nonatomic, strong) GCDTimer  *currentimer;

@end

@implementation HippoManager

static HippoManager* _instance = nil;
+ (instancetype)shareInstance
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[self alloc] init];
    });
    return _instance ;
}
//判断数据库是否存在 不存在就开始创建
- (void)createSqlite {
    HippoModel *model = [[HippoToolManager shareInstance] readData];
    if (model == nil) {
        //不存在了
        [[HippoToolManager shareInstance] createSqlite];
        [[HippoToolManager shareInstance] insertDataId:@"1" actionTime:[[HippoToolManager shareInstance] getCurrentTiem] changeExpTime:[[HippoToolManager shareInstance] getCurrentTiem] changeMoodTime:[[HippoToolManager shareInstance] getCurrentTiem] food:1.0 exp:1.0 mood:1.0 shitNumber:1.0 downStatus:@"0" changeShitTime:[[HippoToolManager shareInstance] getCurrentTiem]];
        
    }
}

#pragma mark - GCDTimer
/**
 计时开始

 @param success 回调
 */
- (void)configDataWithGcdTimerSuccess:(void (^)(float mood,float food,float exp))success {
    __weak __typeof(self) weakSelf = self;
    self.gcdTimer = [[GCDTimer alloc] initInQueue:[GCDQueue mainQueue]];
    self.chooseBtnViewBlock = success;
    [self.gcdTimer event:^{
        //
        [weakSelf configDataWithModel:[[HippoToolManager shareInstance] getCurrentTiem]];
        
    } timeInterval:NSEC_PER_SEC * 1.0];
    
    [self.gcdTimer start];
}

- (void)configDataWithGifWoth:(NSInteger)time timerSuccess:(void (^)(void))gifSuccess {
    NSInteger secondsCountDown = time;
    __weak __typeof(self) weakSelf = self;
    __block NSInteger timeout = secondsCountDown;
    self.currentimer = [[GCDTimer alloc] initInQueue:[GCDQueue mainQueue]];
    [self.currentimer event:^{
        //
        if(timeout <= 0){ //  当倒计时结束时做需要的操作: 关闭 活动到期不能提交
            [weakSelf.currentimer destroy];
            weakSelf.currentimer = nil;
            gifSuccess();
        } else { // 倒计时重新计算 时/分/秒
            timeout--; // 递减 倒计时-1(总时间以秒来计算)
        }
        
    } timeInterval:NSEC_PER_SEC * 1.0 delay:timeout];
    
    [self.currentimer start];
}
/**
 初始化model

 @return model
 */
- (HippoModel *)configDataWithModel {
    HippoModel *model = [[HippoToolManager shareInstance] readData];
    if (model == nil) {
        //不存在了
        [[HippoManager shareInstance] createSqlite];
        HippoModel *changeModel = [[HippoToolManager shareInstance] readData];
        return changeModel;
    } else {
        return model;
    }
}

/**
 初始化河马状态

 @return 河马状态
 */
- (SummerOrderStatus)configDataNormalWithUI {
    HippoModel *model =  [[HippoManager shareInstance] configDataWithModel];
    float moodNumber = model.mood; //当前的心情
    NSString *endDownStatus = model.downStatus; //当前河马状态
    if (moodNumber <= 0.2) {
        //变成蛋
        return EGG;
    } else if ([endDownStatus isEqualToString:@"1"]) {
        //趴下
        return GETDOWN;
    } else {
        return ACTIVE;
    }
    
}


/**
 计时开始

 @param time 当前时间
 */
- (void)configDataWithModel:(NSString *)time {
    HippoModel *model = [[HippoManager shareInstance] configDataWithModel];
    //    NSLog(@"summer--mood--%lf",model.mood);
    //    NSLog(@"summer--%hd",model.shitNumber);
    //    NSLog(@"summer--%@",model.downStatus);
    //    NSLog(@"summer--%@",model.changeShitTime);
    //    NSLog(@"summer--changeMoodTime--%@",model.changeMoodTime);
    //    NSLog(@"summer--%@",model.changeExpTime);
    //    NSLog(@"summer--%@",model.actionTime);
    //    NSLog(@"summer--time--%@",time);
    float moodNumber = model.mood; //当前的心情
    float foodNumber = model.food; //当前的食物总量
    float expNumber = model.exp; //当前的饱程度
    int16_t shitNumber = model.shitNumber; //当前的便便量
    long int shitNumberTime = [time integerValue] - [model.changeShitTime integerValue]; //屎太多  -- 开始影响心情
    long int moodNumberTime = [time integerValue] - [model.changeMoodTime integerValue]; //河马拉屎的间隔
    long int actionNumberTime = [time integerValue] - [model.actionTime integerValue]; //河马是否趴下 -- 差值
    long int expNumberTime = [time integerValue] - [model.changeExpTime integerValue]; //饥饿度 -- 差值
    
    NSString *endDownStatus = model.downStatus; //当前河马状态
    NSString *endExpNumberTime = model.changeExpTime; //最后饥饿度
    NSString *endMoodNumberTime = model.changeMoodTime; //最后河马拉屎时间
    NSString *endActionNumberTime = model.actionTime; //最后趴下时间
    NSString *endShitTime = model.changeShitTime; //屎太多影响心情的时间
    
    //饥饿度
    if (expNumber == 0.0) {
        //已经没有的消耗了  -- 保存当前时间为饥饿度时间
        endExpNumberTime = time;
    } else {
        int extInt = (int)expNumberTime;
        int number = extInt / HippoExpTime;
        if (number > 0) {
            //开始消耗饥饿度
            float expChangeNumber = 0.1 * (float)number;
            if (expNumber > expChangeNumber) {
                //饥饿度 为相减
                expNumber = expNumber - expChangeNumber;
            } else {
                //饥饿度减为0
                expNumber = 0;
            }
            endExpNumberTime = time;
        }
    }
    //心情
    if (moodNumber == 0.0) {
        //心情最差 -- 屎最多
        endMoodNumberTime = time;
        endShitTime = time;
    } else {
        if (shitNumber > HippoShitNumer) {
            //开始影响心情
            int number = (int)shitNumberTime / HippoMoodTime;
            if (number > 0) {
                //开始消耗心情
                float moodChangeNumber = 0.1 * (float)number;
                if (moodNumber > moodChangeNumber) {
                    //心情 为相减
                    moodNumber = moodNumber - moodChangeNumber;
                } else {
                    //心情为0
                    moodNumber = 0;
                }
                endShitTime = time;
            }
        }
        int number = (int)moodNumberTime / HippoShitTime;
        if (number > 0) {
            //开始拉屎
            int entNumber = shitNumber + number;
            if (entNumber == HippoShitNumer + 1) {
                shitNumber = entNumber;
                endMoodNumberTime = time;
                endShitTime = time;
            } else if (entNumber < HippoShitNumer + 1) {
                shitNumber = entNumber;
                endMoodNumberTime = time;
            } else {
                if (shitNumber <= HippoShitNumer) {
                    //原来的不影响 -- 心情
                    float endMoodNumber = [self configCurrenShit:shitNumber shitNewNumber:number];
                    moodNumber = moodNumber - endMoodNumber;
                    if (moodNumber < 0.0) {
                        moodNumber = 0.0;
                    }
                    endShitTime = time;
                }
                shitNumber = entNumber;
                endMoodNumberTime = time;
            }
        }
    }
    //河马趴下
    int number = (int)actionNumberTime / HippoDownTime;
    if (number > 0 ) {
        endActionNumberTime = time;
        endDownStatus = @"1";
    }
//        if (moodNumber != model.mood || expNumber != model.exp || foodNumber != model.food || endActionNumberTime == time || endExpNumberTime == time || endMoodNumberTime == time || shitNumber !=  model.shitNumber || endDownStatus != model.downStatus || endShitTime == time) {
//            [[HippoToolManager shareInstance] updateDataId:@"1" actionTime:endActionNumberTime changeExpTime:endExpNumberTime changeMoodTime:endMoodNumberTime food:foodNumber exp:expNumber mood:moodNumber shitNumber:shitNumber downStatus:endDownStatus changeShitTime:endShitTime];
//        }
//
//        if (moodNumber != model.mood || expNumber != model.exp || foodNumber != model.food) {
//            [self.hippoBodyView configChangeUIWithData:moodNumber andExpNumber:expNumber andFoodNumber:foodNumber];
//        }
    [[HippoToolManager shareInstance] updateDataId:@"1" actionTime:endActionNumberTime changeExpTime:endExpNumberTime changeMoodTime:endMoodNumberTime food:foodNumber exp:expNumber mood:moodNumber shitNumber:shitNumber downStatus:endDownStatus changeShitTime:endShitTime];
    if (self.chooseBtnViewBlock) {
        self.chooseBtnViewBlock(moodNumber,foodNumber,expNumber);
    }
//    [self.hippoBodyView configChangeUIWithData:moodNumber andExpNumber:expNumber andFoodNumber:foodNumber];
}
/**
 清理便便事件

 @param clearShitSuccess 返回数据刷新页面
 */
- (void)configDataWithClearShitSuccess:(void (^)(float mood,float food,float exp))clearShitSuccess {
    HippoModel *model = [[HippoManager shareInstance] configDataWithModel];
    float moodNumber = model.mood; //当前的心情
    float foodNumber = model.food; //当前的食物总量
    float expNumber = model.exp; //当前的饱程度
    int16_t shitNumber = model.shitNumber; //当前的便便量
    NSString *endDownStatus = model.downStatus; //当前河马状态
    NSString *endExpNumberTime = model.changeExpTime; //最后饥饿度
    NSString *endMoodNumberTime = model.changeMoodTime; //最后河马拉屎时间
    NSString *endActionNumberTime = model.actionTime; //最后趴下时间
    NSString *endShitTime = model.changeShitTime; //屎太多影响心情的时间
    shitNumber = 0;
    endShitTime = [[HippoToolManager shareInstance] getCurrentTiem];
    endMoodNumberTime = [[HippoToolManager shareInstance] getCurrentTiem];
    [[HippoToolManager shareInstance] updateDataId:@"1" actionTime:endActionNumberTime changeExpTime:endExpNumberTime changeMoodTime:endMoodNumberTime food:foodNumber exp:expNumber mood:moodNumber shitNumber:shitNumber downStatus:endDownStatus changeShitTime:endShitTime];
    clearShitSuccess(moodNumber,foodNumber,expNumber);
}

/**
 喂食

 @param eatSuccess 回调
 */
- (void)configDataWithEatSuccess:(void (^)(float mood,float food,float exp))eatSuccess {
    HippoModel *model = [[HippoToolManager shareInstance] readData];
    float moodNumber = model.mood; //当前的心情
    float foodNumber = model.food; //当前的食物总量
    float expNumber = model.exp; //当前的饱程度
    int16_t shitNumber = model.shitNumber; //当前的便便量
    NSString *endDownStatus = model.downStatus; //当前河马状态
    NSString *endExpNumberTime = model.changeExpTime; //最后饥饿度
    NSString *endMoodNumberTime = model.changeMoodTime; //最后河马拉屎时间
    NSString *endActionNumberTime = model.actionTime; //最后趴下时间
    NSString *endShitTime = model.changeShitTime; //屎太多影响心情的时间
    if (foodNumber <= 0 || expNumber > 0.95) {
        return;
    }
    foodNumber = foodNumber - 0.1;
    expNumber = expNumber + 0.1;
    [[HippoToolManager shareInstance] updateDataId:@"1" actionTime:endActionNumberTime changeExpTime:endExpNumberTime changeMoodTime:endMoodNumberTime food:foodNumber exp:expNumber mood:moodNumber shitNumber:shitNumber downStatus:endDownStatus changeShitTime:endShitTime];
    eatSuccess(moodNumber,foodNumber,expNumber);
}

/**
 添加食物

 @param food 添加的食物
 @param foodSuccess 成功得回调
 */
- (void)configDataWithAddFood:(CGFloat)food foodSuccess:(void (^)(float mood,float food,float exp))foodSuccess {
    HippoModel *model = [[HippoToolManager shareInstance] readData];
    float moodNumber = model.mood; //当前的心情
    float foodNumber = model.food; //当前的食物总量
    float expNumber = model.exp; //当前的饱程度
    int16_t shitNumber = model.shitNumber; //当前的便便量
    NSString *endDownStatus = model.downStatus; //当前河马状态
    NSString *endExpNumberTime = model.changeExpTime; //最后饥饿度
    NSString *endMoodNumberTime = model.changeMoodTime; //最后河马拉屎时间
    NSString *endActionNumberTime = model.actionTime; //最后趴下时间
    NSString *endShitTime = model.changeShitTime; //屎太多影响心情的时间
    foodNumber = foodNumber + food;
    if (foodNumber > 0.95) {
        foodNumber = 1.0;
    }
    [[HippoToolManager shareInstance] updateDataId:@"1" actionTime:endActionNumberTime changeExpTime:endExpNumberTime changeMoodTime:endMoodNumberTime food:foodNumber exp:expNumber mood:moodNumber shitNumber:shitNumber downStatus:endDownStatus changeShitTime:endShitTime];
    foodSuccess(moodNumber,foodNumber,expNumber);
}

/**
 添加心情

 @param mood 添加的心情
 @param moodSuccess 成功回调
 */
- (void)configDataWithAddMood:(CGFloat)mood moodSuccess:(void (^)(float mood,float food,float exp))moodSuccess {
    HippoModel *model = [[HippoToolManager shareInstance] readData];
    float moodNumber = model.mood; //当前的心情
    float foodNumber = model.food; //当前的食物总量
    float expNumber = model.exp; //当前的饱程度
    int16_t shitNumber = model.shitNumber; //当前的便便量
    NSString *endDownStatus = model.downStatus; //当前河马状态
    NSString *endExpNumberTime = model.changeExpTime; //最后饥饿度
    NSString *endMoodNumberTime = model.changeMoodTime; //最后河马拉屎时间
    NSString *endActionNumberTime = model.actionTime; //最后趴下时间
    NSString *endShitTime = model.changeShitTime; //屎太多影响心情的时间
    moodNumber = moodNumber + mood;
    if (foodNumber > 0.95) {
        moodNumber = 1.0;
    }
    [[HippoToolManager shareInstance] updateDataId:@"1" actionTime:endActionNumberTime changeExpTime:endExpNumberTime changeMoodTime:endMoodNumberTime food:foodNumber exp:expNumber mood:moodNumber shitNumber:shitNumber downStatus:endDownStatus changeShitTime:endShitTime];
    moodSuccess(moodNumber,foodNumber,expNumber);
}
/**
 计算影响心情数量
 
 @param shitNumber 原来就有的屎量
 @param shitNewNumber 新产生的
 @return 影响的心情
 */
- (float)configCurrenShit:(int)shitNumber shitNewNumber:(int)shitNewNumber {
    
    int chatShitNumber = shitNumber + shitNewNumber - HippoShitNumer - 1;
    int changeNumber = HippoShitTime * chatShitNumber / HippoMoodTime;
    return 0.1 * changeNumber;
}

@end
